package com.example.login1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login1Application {

    public static void main(String[] args) {
        SpringApplication.run(Login1Application.class, args);
    }

}
